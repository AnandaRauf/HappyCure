import 'dart:async';
import 'package:flutter/material.dart';

import 'package:splash_screen_view/SplashScreenView.dart';

import 'package:happycure/page/home.dart';
import 'package:happycure/main.dart';

class LoadingPage extends StatefulWidget {
  @override
  LoadingScreen createState() => LoadingScreen();
}

@override
class LoadingScreen extends State<LoadingPage> {
  @override
  Widget build(BuildContext context) {
    return SplashScreenView(
      navigateRoute: HomePageHappyCure(), //MainScanPage(),
      duration: 3000,
      imageSize: 150,
      imageSrc: "asset/happy_cure_loading.png",
      text: 'Happy Cure',
      textType: TextType.ColorizeAnimationText,
      textStyle: TextStyle(
        fontSize: 12.0,
      ),
      colors: [
        Colors.red,
        Colors.white,
        Colors.green,
        Colors.yellow,
      ],
      backgroundColor: Colors.white,
    );
  }
}
