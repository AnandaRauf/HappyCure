import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flat_icons_flutter/flat_icons_flutter.dart';
import 'package:happycure/page/leaderdev.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:tflite/tflite.dart';
import 'package:image_picker/image_picker.dart';
import 'package:camera/camera.dart';
import 'dart:async';

class HomePageHappyCure extends StatefulWidget {
  @override
  HomePages createState() => HomePages();
}

class HomePages extends State<HomePageHappyCure> {
  List _results;
  File Filegambar;
  @override
  void initState() {
    super.initState();
    loadModel();
  }

  @override
  void dispose() {
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return new Scaffold(
      appBar: AppBar(
        title: Text("Happy Cure"),
      ),
      body: Column(
        children: [
          if (Filegambar != null)
            Container(margin: EdgeInsets.all(10), child: Image.file(Filegambar))
          else
            Container(
              margin: EdgeInsets.all(40),
              child: Opacity(
                opacity: 0.6,
                child: Center(
                  child: Text('Disease not detected'),
                ),
              ),
            ),
          SingleChildScrollView(
            child: Column(
              children: _results != null
                  ? _results.map((result) {
                      return Card(
                        child: Container(
                          margin: EdgeInsets.all(10),
                          child: Text(
                            "${result["label"]} -  ${result["confidence"].toStringAsFixed(2)}",
                            style: TextStyle(color: Colors.red, fontSize: 12.0, fontWeight: FontWeight.bold),
                          ),
                        ),
                      );
                    }).toList()
                  : [],
            ),
          ),
        ],
      ),
      drawer: Drawer(
        child: ListView(
          padding: EdgeInsets.zero,
          children: [
            DrawerHeader(
              decoration: BoxDecoration(
                color: Colors.black,
              ),
              child: Text(
                'Happy Cure(Cure Person Happy Person)',
                style: TextStyle(
                  color: Colors.red,
                  fontSize: 16,
                ),
              ),
            ),
            ListTile(
              title: const Text('Follow Instagram Leader Dev'),
              leading: Icon(FlatIcons.con_instagram),
              onTap: () {
                Fluttertoast.showToast(msg: "Opening Instagram...", toastLength: Toast.LENGTH_SHORT, gravity: ToastGravity.CENTER, timeInSecForIosWeb: 5, backgroundColor: Colors.white, textColor: Colors.black, fontSize: 14.0);
                Navigator.push(context, MaterialPageRoute(builder: (context) => WebPageLeaderDev()));
              },
            ),
            ListTile(
              title: const Text('Take picture for scan disease'),
              leading: Icon(FlatIcons.photo_camera_1),
              onTap: () {
                Fluttertoast.showToast(msg: "Opening Camera...", toastLength: Toast.LENGTH_SHORT, gravity: ToastGravity.CENTER, timeInSecForIosWeb: 5, backgroundColor: Colors.white, textColor: Colors.black, fontSize: 14.0);
                showAlertDialogCamera(context);
              },
            ),
            ListTile(
              title: const Text('Import picture from galery for scan disease'),
              leading: Icon(FlatIcons.picture),
              onTap: () {
                Fluttertoast.showToast(msg: "Opening Galery...", toastLength: Toast.LENGTH_SHORT, gravity: ToastGravity.CENTER, timeInSecForIosWeb: 5, backgroundColor: Colors.white, textColor: Colors.black, fontSize: 14.0); //Navigator.push(context, MaterialPageRoute(builder: (context) => PokerGamesPage()));
                showAlertDialogGalery(context);
              },
            ),
            ListTile(
              title: const Text('About App'),
              leading: Icon(FlatIcons.info),
              onTap: () {
                Fluttertoast.showToast(msg: "Happy Cure\nVersion 1.0\nDeveloped by Tech Futuristic team", toastLength: Toast.LENGTH_SHORT, gravity: ToastGravity.CENTER, timeInSecForIosWeb: 5, backgroundColor: Colors.white, textColor: Colors.black, fontSize: 14.0);
              },
            ),
          ],
        ),
      ),
    );
  }

  showAlertDialogCamera(BuildContext context) {
    Widget Yesbutton = FlatButton(
      child: Text("Yes"),
      onPressed: () async {
        await pickImage(ImageSource.camera);
      },
    );
    Widget Nobutton = FlatButton(
      child: Text("No"),
      onPressed: () {
        Navigator.push(context, MaterialPageRoute(builder: (context) => HomePageHappyCure()));
      },
    );
    AlertDialog alert = AlertDialog(
      title: Text("Camera Handphone"),
      content: Text("Open Camera?"),
      actions: [
        Nobutton,
        Yesbutton,
      ],
    );
    showDialog(
        context: context,
        builder: (BuildContext context) {
          return alert;
        });
  }

  showAlertDialogGalery(BuildContext context) {
    Widget Yesbutton = FlatButton(
      child: Text("Yes"),
      onPressed: () async {
        await pickImage(ImageSource.gallery);
      },
    );
    Widget Nobutton = FlatButton(
      child: Text("No"),
      onPressed: () {
        Navigator.push(context, MaterialPageRoute(builder: (context) => HomePageHappyCure()));
      },
    );
    AlertDialog alert = AlertDialog(
      title: Text("Gallery Handphone"),
      content: Text("Open Gallery?"),
      actions: [
        Nobutton,
        Yesbutton,
      ],
    );
    showDialog(
        context: context,
        builder: (BuildContext context) {
          return alert;
        });
  }

  Future loadModel() async {
    await Tflite.loadModel(model: 'assets/model_unquant.tflite', labels: 'assets/labels.txt');
  }

  void pickImage(ImageSource imageSource) async {
    var image = await ImagePicker().pickImage(source: imageSource);
    if (image == null) {
      return null;
    }
    setState(() {
      Filegambar = File(image.path);
    });
    processImage(Filegambar);
  }

  Future processImage(File image) async {
    // Run tensorflowlite image classification model on the image
    final List results = await Tflite.runModelOnImage(
      path: image.path,
      numResults: 2,
      threshold: 0.5,
      imageMean: 127.5,
      imageStd: 127.5,
    );
    setState(() {
      _results = results;
      Filegambar = image;
    });
  }
}
