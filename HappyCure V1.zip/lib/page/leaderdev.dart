import 'package:flutter/material.dart';
import 'dart:io';
import 'package:webview_flutter/webview_flutter.dart';

class WebPageLeaderDev extends StatefulWidget {
  @override
  WebPages createState() => WebPages();
}

class WebPages extends State<WebPageLeaderDev> {
  @override
  Widget build(BuildContext context) {
    return new WebView(
      initialUrl: 'https://www.instagram.com/anandaraufm/',
    );
    AppBar(
      title: Text("Instagram Leader Dev"),
    );
  }
}
